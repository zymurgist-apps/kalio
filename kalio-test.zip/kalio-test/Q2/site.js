$(document).ready(function(){
    colorSetup();
})

var colorSetup = function(){
    let $colorMe = $('#color-me')
    $('a').click(function(){        
        let color = $(this).attr('id');
        $colorMe.css('backgroundColor', color);
    })
}
